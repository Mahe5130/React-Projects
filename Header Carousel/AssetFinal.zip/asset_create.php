<?php

include "config.php";
session_start();


if (isset($_SESSION['username'])) {

  $user_email = $_SESSION['username'];

  if (isset($_POST['submit'])) {

    $first_name = $_POST['firstname'];
    $last_name = $_POST['lastname'];
    $email = $_POST['email'];
    $employee_id = $_POST['employeeid'];
    $designation = $_POST['designation'];
    $department = $_POST['department'];
    $reporting_manager = $_POST['reportingmanager'];
    $receiving_date = $_POST['receivingdate'];
    $system_brand = $_POST['systembrand'];
    $product_id = $_POST['productid'];
    $processor = $_POST['processor'];
    $date = date("Y-m-d");

    if (empty($first_name) || empty($last_name) || empty($email) || empty($employee_id) || empty($designation) || empty($department) || empty($reporting_manager) || empty($receiving_date) || empty($system_brand) || empty($product_id) || empty($processor) || empty($date)) {

      echo '<script>alert("please insert the values")</script>';
    } else {

      if (filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $sql = "INSERT INTO `users`(`first_name`, `last_name`, `email`, `employee_id`, `designation`,`department`,`reporting_manager`,`receiving_date`,`system_brand`,`product_id`,`processor`,`submited_date` ) VALUES ('$first_name','$last_name','$email','$employee_id','$designation', '$department', '$reporting_manager', '$receiving_date', '$system_brand', '$product_id', '$processor', '$date')";

        $result = $conn->query($sql);

        if ($result == TRUE) {

          $sql4 = "UPDATE `employee` SET is_submit = 1 WHERE `emp_email` = '$email'";

          $result4 = $conn->query($sql4);

          header("Location: Thank.php");
          exit();
        } else {
          echo '<script>alert("Failed to save the Records")</script>';
        }
      } else {
        echo '<script>alert("please insert a valid email address")</script>';
      }
    }

    $conn->close();
  }

?>

  <!DOCTYPE html>

  <html>


  <head>
    <meta http-equiv="refresh" content="600; url= logout.php">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <style>
      * {
        padding: 0;
        margin: 0;
        font-family: 'Poppins', sans-serif;
      }

      .btn {
        background-color: #1abc9c;
        color: #fff;
      }
    </style>

    <script>
      if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
      }
    </script>
    <title>asset form</title>


  </head>

  <body>
    <hr>

    <h2 align="center">Asset Form</h2>
    <hr>
    <br>
    <div class="container">
      <form method="POST" action="" class="row g-3" target="_self" Id="assetForm">

        <div class="col-12 col-md-6 col-sm-12">
          <label for="inputFirstname" class="form-label">First Name</label>
          <input type="text" class="form-control" placeholder="First name" aria-label="First name" name="firstname" pattern="[A-Za-z\s]*" required>

        </div>
        <div class="col-12 col-md-6 col-sm-12">
          <label for="inputLastname" class="form-label">Last Name</label>
          <input type="text" class="form-control" placeholder="Last name" aria-label="Last name" name="lastname" pattern="[A-Za-z\s]*" required>

        </div>
        <div class="col-12 col-md-6 col-sm-12">
          <label for="inputEmail4" class="form-label">Email</label>
          <input type="email" class="form-control" placeholder="Email" name="email" value="<?php echo $user_email ?>" readonly>

        </div>
        <div class="col-12 col-md-6 col-sm-12">
          <label for="inputEmployeeid" class="form-label">Employee ID</label>
          <input type="text" class="form-control" placeholder="Employee Id" name="employeeid" required>
        </div>
        <div class="col-12 col-md-6 col-sm-12">
          <label for="inputDesignation" class="form-label">Designation</label>
          <input type="text" class="form-control" placeholder="Designation" name="designation" required>

        </div>
        <div class="col-12 col-md-6 col-sm-12">
          <label for="inputDepartment" class="form-label">Department</label>
          <input type="text" class="form-control" placeholder="Department" name="department" required>

        </div>
        <div class="col-12 col-md-6 col-sm-12">
          <label for="inputReportingmanager" class="form-label">Reporting Manager</label>
          <input type="text" class="form-control" placeholder="Reporting Manager" name="reportingmanager" required>

        </div>
        <div class="col-6 col-md-6 com-sm-12 ">
          <label for="inputReceivingdate" class="form-label">Receiving Date</label>
          <input type="date" class="form-control" placeholder="Receiving Date" name="receivingdate" required>

        </div>
        <div class="col-6 col-md-6 col-sm-12">
          <label for="inputLaptop/Desktop Brand" class="form-label">Laptop/Desktop Brand</label>
          <input type="text" class="form-control" placeholder="Laptop/Desktop Brand" name="systembrand" required>

        </div>
        <div class="col-12 col-md-6 col-sm-12">
          <label for="inputProductid" class="form-label">Product ID</label>
          <input type="text" class="form-control" placeholder="Product Id" name="productid" required>
        </div>

        <div class="col-12 col-md-6  col-sm-12">
          <label for="inputProcessor" class="form-label">Processor</label>
          <input type="text" class="form-control" placeholder="Processor" name="processor" required>

        </div>
        <div class="col-md-12 col-sm-12">
          <input class="form-check-input" type="checkbox" id="flexCheckDefault" required>
          <label class="form-check-label" for="flexCheckDefault">
            I hereby confirm that the above mentioned information is correct and I have received the Laptop / System in
            good working condition.</label>
        </div>

        <div class="col-12">
          <button type="submit" class="btn" name="submit">Submit</button>
        </div>
      </form>
      <hr>

    </div>

  </body>

  </html>
<?php
} else {
  header("Location: asset_login.php");

  exit();
}
