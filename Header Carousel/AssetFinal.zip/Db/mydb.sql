-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2023 at 08:53 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `emp_email` varchar(50) NOT NULL,
  `is_active` tinyint(4) NOT NULL,
  `is_submit` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `emp_email`, `is_active`, `is_submit`) VALUES
(1, 'vijay@designshop247.com', 0, 1),
(2, 'anamika.bhatnagar@designshop247.com', 1, 0),
(3, 'sahil@designshop247.com', 1, 0),
(4, 'hemashree.chetia@designshop247.com', 0, 1),
(5, 'mohan.vishwakarma@designshop247.com', 1, 0),
(6, 'dev@designshop247.com', 1, 0),
(7, 'mahendran.p@designshop247.com', 1, 0),
(8, 'hammad@designshop247.com', 0, 1),
(9, 'tamil.chindhu@designshop247.com', 1, 0),
(10, 'dayan.malik@designshop247.com', 1, 0),
(11, 'hema.m@designshop247.com', 1, 0),
(12, 'akash.upadhyay@designshop247.com', 1, 0),
(13, 'cindy.mascarenhas@designshop247.com', 1, 0),
(14, 'divyang.dublish@designshop247.com', 1, 0),
(15, 'Vinay@designshop247.com', 1, 0),
(16, 'suprith@designshop247.com', 1, 0),
(17, 'jd@buzznationmarketing.com', 1, 0),
(18, 'rahul@buzznationmarketing.com', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `employee_id` varchar(20) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `department` varchar(50) NOT NULL,
  `reporting_manager` varchar(50) NOT NULL,
  `receiving_date` date NOT NULL,
  `system_brand` varchar(50) NOT NULL,
  `product_id` text NOT NULL,
  `processor` varchar(50) NOT NULL,
  `submited_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `employee_id`, `designation`, `department`, `reporting_manager`, `receiving_date`, `system_brand`, `product_id`, `processor`, `submited_date`) VALUES
(1, 'Vijay', 'Pratap Singh', 'vijay@designshop247.com', 'CGSM111', 'Sr. Key Account Manager', 'Sales', 'Nitin Dhawan', '2023-06-03', 'Lenovo', 'E14', 'i3', '2023-08-11'),
(2, 'Hemashree', 'Chetia', 'hemashree.chetia@designshop247.com', 'CSGM106', 'Events Co-Ordinator', 'Events & Exhibitions', 'Anamika Bhatnagar', '2022-12-19', 'Lenovo Thinkpad', '20TAS0XH00', 'i3', '2023-08-11'),
(3, 'Hammad', 'Ahmad', 'hammad@designshop247.com', 'D247009', 'Database Specialist', 'Technology', 'Dhivakar Vijaykumar', '2022-04-25', 'Lenovo Thinkpad', '00330-50000-00000-AAOEM', '11th Gen Intel(R) Core(TM) i3-1115G4 @ 3.00GHz   3', '2023-08-11');

-- --------------------------------------------------------

--
-- Table structure for table `user_access`
--

CREATE TABLE `user_access` (
  `id` int(11) NOT NULL,
  `code` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_access`
--

INSERT INTO `user_access` (`id`, `code`) VALUES
(1, 10001);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_access`
--
ALTER TABLE `user_access`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_access`
--
ALTER TABLE `user_access`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
