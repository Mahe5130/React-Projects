<?php
include('config.php');
session_start();

if (isset($_POST['email'])) {

    function validate($data)
    {

        $data = trim($data);

        $data = stripslashes($data);

        $data = htmlspecialchars($data);

        return $data;
    }

    $email = validate($_POST['email']);

    $sql = "SELECT * FROM employee WHERE emp_email='$email'";

    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) === 1) {

        $row = mysqli_fetch_assoc($result);

        $is_submit = $row['is_submit'];

        $is_active = $row['is_active'];

        if ($is_active == 1) {
            if ($is_submit == 1) {
                $_SESSION['username'] = $row['emp_email'];

                $getIdSql = "SELECT id FROM users WHERE email = '$email'";

                $resultId = mysqli_query($conn, $getIdSql);

                if ($resultId == true) {

                    $getId = mysqli_fetch_assoc($resultId);

                    $_SESSION['id'] = $getId['id'];
                    header("Location: update.php");
                    exit();
                } else {
                    header("Location: asset_login.php?error=Something is wrong");

                    exit();
                }
            } else {
                $_SESSION['username'] = $row['emp_email'];
                header("Location: asset_create.php");
                exit();
            }
        } else {
            header("Location: asset_login.php?error=Access Denied");
            exit();
        }
    } else {
        header("Location: asset_login.php?error=Access Denied");
        exit();
    }
}
