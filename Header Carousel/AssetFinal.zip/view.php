<?php

include "config.php";
session_start();
if (isset($_SESSION['code']) && isset($_SESSION['id'])) {

  $num_per_page = 05;

  if (isset($_GET["page"])) {
    $page = $_GET["page"];
  } else {
    $page = 1;
  }

  $start_from = ($page - 1) * 05;
  if ($page > 1) {
    $count = (($page - 1) * $num_per_page) + 1;
  } else {
    $count = 1;
  }

  $sql = "SELECT *, DATE_FORMAT(receiving_date,'%d-%m-%Y') as formatDate, DATE_FORMAT(submited_date,'%d-%m-%Y') as submittedFormatDate FROM users limit $start_from,$num_per_page";

  $result = $conn->query($sql);

?>


  <!DOCTYPE html>

  <html>

  <head>

    <style>
      * {
        padding: 0;
        margin: 0;
        font-family: 'Poppins', sans-serif;
      }

      .cap {
        text-transform: capitalize;
      }

      /* pagination */

      .pagination {
        display: inline-block;
      }

      .pagination a {
        color: black;
        float: left;
        padding: 8px 16px;
        text-decoration: none;
        transition: background-color .3s;
        border: 1px solid #ddd;
        margin: 0 4px;
      }
    </style>

    <title>View Page</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

  </head>

  <body>

    <div class="container">

      <u>
        <h2>Employee Details</h2>
      </u>
      <hr>

      <div align="right" class="col-12">
        <a href="logout1.php"><button type="submit" class="btn btn-danger" name="logout" value="logout">Logout</button></a>
      </div>

      <table class="table" style="border: 1px solid #000" ;>

        <thead>

          <tr>

            <th>Sr.No</th>

            <th>First Name</th>

            <th>Last Name</th>

            <th>Email</th>

            <th>Employee Id</th>

            <th>Designation</th>

            <th>Department</th>

            <th>Reporting Manager</th>

            <th>Receiving Date</th>

            <th>System Brand</th>

            <th>Product Id</th>

            <th>Processor</th>

            <th>Submitted Date</th>

          </tr>

        </thead>

        <tbody>

          <?php
          if ($result->num_rows > 0) {

            while ($row = $result->fetch_assoc()) {
          ?>

              <tr>

                <td><?php echo $count; ?></td>

                <td class="cap"><?php echo $row['first_name']; ?></td>

                <td class="cap"><?php echo $row['last_name']; ?></td>

                <td><?php echo $row['email']; ?></td>

                <td><?php echo $row['employee_id']; ?></td>

                <td class="cap"><?php echo $row['designation']; ?></td>

                <td class="cap"><?php echo $row['department']; ?></td>

                <td><?php echo $row['reporting_manager']; ?></td>

                <td><?php echo $row['formatDate']; ?></td>

                <td><?php echo $row['system_brand']; ?></td>

                <td><?php echo $row['product_id']; ?></td>

                <td><?php echo $row['processor']; ?></td>

                <td><?php echo $row['submittedFormatDate']; ?></td>

              </tr>

          <?php
              $count++;
            }
          }

          ?>

          <?php

          $sql = "SELECT *, DATE_FORMAT(receiving_date,'%d-%m-%Y') as formatDate, DATE_FORMAT(submited_date,'%d-%m-%Y') as submittedFormatDate FROM users";

          $result = $conn->query($sql);
          $total_records = mysqli_num_rows($result);
          $total_pages = ceil($total_records / $num_per_page);
          ?>
          <div class="pagination">
            <?php
            for ($i = 1; $i <= $total_pages; $i++) {


              echo "<a id='$i' href='view.php?page=" . $i . "'>" . $i . "</a>";
            } ?>
          </div>


        </tbody>

      </table>

    </div>

  </body>

  </html>

<?php } else {
  header("Location: view_login.php");
  exit();
} ?>