<?php

session_start();

session_destroy();

unset($_SESSION['code']);

header("Location: view_login.php");
