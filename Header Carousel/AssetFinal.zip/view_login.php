<!DOCTYPE html>
<html>

<head>
  <title>Asset View Login Form</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <!-- Option 1: Include in HTML -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
  <style>
  @import url('https://fonts.googleapis.com/css2?family=Poppins&display=swap');

  * {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
  }

  body {
    height: 100vh;
    background: #aaa;
  }

  .container {
    margin: 50px auto;
  }

  .panel-heading {
    text-align: center;
    margin-bottom: 10px;
  }

  .far,
  .fas {
    color: #000;
  }

  .form-inline label {
    padding-left: 10px;
    margin: 0;
    cursor: pointer;
  }

  .btn.btn-success {
    margin-top: 20px;
    border-radius: 15px;
  }

  .panel {
    min-height: 410px;
    box-shadow: 20px 20px 80px rgb(218, 218, 218);
    border-radius: 12px;
  }

  .input-field {
    border-radius: 5px;
    padding: 5px;
    display: flex;
    align-items: center;
    cursor: pointer;
    border: 1px solid #ddd;
    color: #4343ff;
  }

  input[type='text'],
  input[type='password'] {
    border: none;
    outline: none;
    box-shadow: none;
    width: 100%;
  }


  img {

    height: 100px;
    object-fit: cover;

    position: relative;
  }

  a[target='_blank'] {
    position: relative;
    transition: all 0.1s ease-in-out;
  }

  .bordert {
    border-top: 1px solid #aaa;
    position: relative;
  }

  .bordert:after {
    content: "or connect with";
    position: absolute;
    top: -13px;
    left: 33%;
    background-color: #fff;
    padding: 0px 8px;
  }

  @media(max-width: 360px) {
    #forgot {
      margin-left: 0;
      padding-top: 10px;
    }

    body {
      height: 100%;
    }

    .container {
      margin: 30px 0;
    }

    .bordert:after {
      left: 25%;
    }
  }
  </style>

</head>

<body>
  <div class="container">
    <div class="row">
      <div class="offset-md-2 col-lg-5 col-md-7 offset-lg-4 offset-md-3">
        <div class="panel border bg-white">
          <div class="panel-heading p-3">
            <img src="image/design247logo1.png" alt="">
            <h3 class="pt-3 font-weight-bold">Asset View Login</h3>
          </div>

          <div class="panel-body p-3">

            <?php if (isset($_GET['error'])) { ?>
            <p class="error"><?php echo $_GET['error']; ?></p>
            <?php } ?>

            <form action="login1.php" method="POST">
              <div class="form-group py-2">
                <div class="input-field">
                  <span class="far fa-user p-2"></span>
                  <input type="text" placeholder="Please Enter The Code" name="code" required>
                </div>
              </div>

              <button type="submit" class="btn btn-success btn-block mt-3">Login</button>
            </form>
          </div>

        </div>
      </div>
    </div>
  </div>
  </div>

</body>

</html>