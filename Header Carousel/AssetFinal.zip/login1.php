<?php
include('config.php');
session_start();

if (isset($_POST['code'])) {

  function validate($data)
  {

    $data = trim($data);

    $data = stripslashes($data);

    $data = htmlspecialchars($data);

    return ($data);
  }

  $code = validate($_POST['code']);


  $sql = "SELECT * FROM user_access WHERE code='$code'";

  $result = mysqli_query($conn, $sql);

  if (mysqli_num_rows($result) === 1) {

    $row = mysqli_fetch_assoc($result);

    $_SESSION['code'] = $row['code'];

    $_SESSION['id'] = $row['id'];

    header("Location: view.php");

    exit();
  } else {
    header("Location: view_login.php?error=Access denied");
  }
} else {

  header("Location: view_login.php");

  exit();
}
